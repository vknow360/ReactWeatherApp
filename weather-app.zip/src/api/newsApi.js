// News API integration for the News screen
// Replace 'YOUR_API_KEY' with your actual News API key

export const fetchNewsData = async (count = 10, query = "weather") => {
    const apiKey = "YOUR_API_KEY"; // Replace with your NewsAPI.org key or another provider
    const url = `https://newsapi.org/v2/everything?q=${encodeURIComponent(
        query
    )}&pageSize=${count}&sortBy=publishedAt&apiKey=${apiKey}`;
    try {
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error("Failed to fetch news");
        }
        const data = await response.json();
        // Normalize to match expected structure
        return (data.articles || []).map((article) => ({
            title: article.title,
            description: article.description,
            link: article.url,
            pubDate: article.publishedAt,
            thumbnail: article.urlToImage,
            categories:
                article.source && article.source.name
                    ? [article.source.name]
                    : [],
        }));
    } catch (error) {
        console.error("News API error:", error);
        return [];
    }
};
